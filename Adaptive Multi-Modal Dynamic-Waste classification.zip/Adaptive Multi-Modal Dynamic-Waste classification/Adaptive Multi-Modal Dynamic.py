# -*- coding: utf-8 -*-
"""
Created on Tue Dec  7 13:52:57 2025
@author: Hanshi
"""


import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
import clip
from PIL import Image
import numpy as np
import random
import json
from torch_geometric.nn import GATv2Conv, global_mean_pool
from torch_geometric.data import Data
from sklearn.neighbors import kneighbors_graph
import hashlib
import time
from tqdm import tqdm
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import StratifiedKFold
import statistics

# 设置随机种子确保结果可复现
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_seed(42)

# 设备配置
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 特征验证工具函数
def check_nan_inf(tensor, name="Tensor"):
    """检查张量中是否有NaN或Inf值"""
    has_nan = torch.isnan(tensor).any()
    has_inf = torch.isinf(tensor).any()
    
    if has_nan or has_inf:
        nan_count = torch.isnan(tensor).sum().item()
        inf_count = torch.isinf(tensor).sum().item()
        
        if has_nan:
            nan_indices = torch.nonzero(torch.isnan(tensor))[0].tolist()
        if has_inf:
            inf_indices = torch.nonzero(torch.isinf(tensor))[0].tolist()
        
        print(f"警告: {name} 包含 {nan_count} 个NaN和 {inf_count} 个Inf")
        tensor = torch.nan_to_num(tensor, nan=0.0, posinf=1e6, neginf=-1e6)
        print(f"已将 {name} 中的NaN/Inf替换为有效值")
        
    return tensor

# 自适应阈值KNN算法
class AdaptiveThresholdKNN:
    def __init__(self, min_k=1, max_k=10, percentile=30, metric='euclidean', device='cpu'):
        self.min_k = min_k
        self.max_k = max_k
        self.percentile = percentile
        self.metric = metric
        self.device = device
        
    def compute_distances(self, features):
        n = features.shape[0]
        features = features.detach().cpu().numpy()
        
        knn_graph = kneighbors_graph(
            features, 
            n_neighbors=min(self.max_k*2, n-1),
            mode='distance',
            metric=self.metric,
            include_self=False
        )
        
        return torch.tensor(knn_graph.toarray(), device=self.device)
    
    def compute_adaptive_threshold(self, distances):
        n = distances.shape[0]
        thresholds = torch.zeros(n, device=self.device)
        
        for i in range(n):
            node_distances = distances[i]
            node_distances = node_distances[node_distances > 0].sort()[0]
            
            if len(node_distances) == 0:
                thresholds[i] = 1.0
                continue
                
            threshold = torch.quantile(node_distances, self.percentile / 100.0)
            neighbors_count = torch.sum(node_distances <= threshold).item()
            
            if neighbors_count < self.min_k:
                if len(node_distances) >= self.min_k:
                    threshold = node_distances[self.min_k - 1]
                else:
                    threshold = node_distances[-1]
            elif neighbors_count > self.max_k:
                threshold = node_distances[self.max_k - 1]
            
            thresholds[i] = threshold
            
        return thresholds
    
    def build_adjacency_matrix(self, distances, thresholds):
        n = distances.shape[0]
        adj_matrix = torch.zeros_like(distances)
        
        for i in range(n):
            threshold = thresholds[i]
            neighbors = (distances[i] <= threshold) & (distances[i] > 0)
            
            if neighbors.sum() > self.max_k:
                top_k_indices = torch.argsort(distances[i])[:self.max_k]
                adj_matrix[i, top_k_indices] = distances[i, top_k_indices]
            else:
                adj_matrix[i, neighbors] = distances[i, neighbors]
        
        adj_matrix = torch.max(adj_matrix, adj_matrix.t())
        return adj_matrix
    
    def __call__(self, features):
        distances = self.compute_distances(features)
        thresholds = self.compute_adaptive_threshold(distances)
        adj_matrix = self.build_adjacency_matrix(distances, thresholds)
        
        edge_index = []
        edge_attr = []
        
        for i in range(adj_matrix.shape[0]):
            for j in range(adj_matrix.shape[1]):
                if i != j and adj_matrix[i, j] > 0:
                    edge_index.append([i, j])
                    edge_attr.append([adj_matrix[i, j]])
        
        if not edge_index:
            edge_index = [[i, i] for i in range(adj_matrix.shape[0])]
            edge_attr = [[1.0] for _ in range(adj_matrix.shape[0])]
        
        edge_index = torch.tensor(edge_index, dtype=torch.long, device=self.device).t().contiguous()
        edge_attr = torch.tensor(edge_attr, dtype=torch.float, device=self.device)
        
        return edge_index, edge_attr

# 数据加载与预处理 - 支持自定义样本列表
class GarbageDataset(Dataset):
    def __init__(self, root_dir=None, transform=None, is_train=True, hide_semantic=True, samples=None):
        self.root_dir = root_dir
        self.transform = transform
        self.is_train = is_train
        self.hide_semantic = hide_semantic
        
        # 获取类别信息
        if root_dir:
            self.classes, self.class_to_idx = self._find_classes(self.root_dir)
        else:
            self.classes, self.class_to_idx = None, None
        
        # 使用传入的样本列表或从根目录生成
        if samples is not None:
            self.samples = samples
        elif root_dir:
            self.samples = self._make_dataset(self.root_dir, self.class_to_idx)
        else:
            self.samples = []
        
        # 生成文件名映射（防止语义泄露）
        if self.is_train and self.hide_semantic:
            self.filename_mapping = {path: f"sample_{i}.jpg" for i, (path, _) in enumerate(self.samples)}
        else:
            self.filename_mapping = {path: f"{hashlib.md5(path.encode()).hexdigest()}.jpg" for path, _ in self.samples}

    def _find_classes(self, dir):
        classes = [d.name for d in os.scandir(dir) if d.is_dir()]
        classes.sort()
        class_to_idx = {cls_name: i for i, cls_name in enumerate(classes)}
        return classes, class_to_idx

    def _make_dataset(self, dir, class_to_idx):
        images = []
        dir = os.path.expanduser(dir)
        for target in sorted(class_to_idx.keys()):
            d = os.path.join(dir, target)
            if not os.path.isdir(d):
                continue
            for root, _, fnames in sorted(os.walk(d)):
                for fname in sorted(fnames):
                    if fname.endswith(('.jpg', '.jpeg', '.png')):
                        path = os.path.join(root, fname)
                        try:
                            img = Image.open(path)
                            img.verify()
                            img.close()
                            item = (path, class_to_idx[target])
                            images.append(item)
                        except Exception as e:
                            print(f"跳过无效图像: {path}, 错误: {e}")
        return images

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        image = Image.open(path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        return {
            'image': image,
            'sub_label': label,
            'filename': self.filename_mapping[path]
        }

# 特征提取器
class FeatureExtractor(nn.Module):
    def __init__(self, visual_dim=2048, clip_dim=512, output_dim=512):
        super().__init__()
        
        cnn_model = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
        modules = list(cnn_model.children())[:-1]
        self.cnn = nn.Sequential(*modules)
        
        for param in list(self.cnn.parameters())[:-5]:
            param.requires_grad = False
        
        self.clip_model, self.clip_preprocess = clip.load("ViT-B/32", device=device)
        for param in self.clip_model.parameters():
            param.requires_grad = False
        
        self.projection = nn.Sequential(
            nn.Linear(visual_dim + clip_dim, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(),
            nn.Linear(1024, output_dim),
            nn.BatchNorm1d(output_dim)
        )
        
        self.visual_dim = visual_dim
        self.clip_dim = clip_dim
        
        self.clip_transform = transforms.Compose([
            transforms.Resize(224, interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.CenterCrop(224),
            transforms.Normalize((0.48145466, 0.4578275, 0.40821073), (0.26862954, 0.26130258, 0.27577711)),
        ])

    def extract_cnn_features(self, images):
        images = check_nan_inf(images, "CNN Input Images")
        features = self.cnn(images)
        features = features.view(features.size(0), -1)
        features = check_nan_inf(features, "CNN Features")
        return features
    
    def extract_clip_features(self, images):
        images = check_nan_inf(images, "CLIP Input Images")
        clip_input = self.clip_transform(images)
        clip_input = check_nan_inf(clip_input, "Processed CLIP Input")
        
        with torch.no_grad():
            clip_features = self.clip_model.encode_image(clip_input)
        
        clip_features = clip_features.float()
        clip_features = check_nan_inf(clip_features, "CLIP Features")
        return clip_features
    
    def forward(self, images):
        images = check_nan_inf(images, "Input Images")
        cnn_features = self.extract_cnn_features(images)
        clip_features = self.extract_clip_features(images)
        combined_features = torch.cat([cnn_features, clip_features], dim=1)
        combined_features = check_nan_inf(combined_features, "Combined Features")
        projected_features = self.projection(combined_features)
        projected_features = check_nan_inf(projected_features, "Projected Features")
        
        return {
            'cnn_features': cnn_features,
            'clip_features': clip_features,
            'combined_features': combined_features,
            'projected_features': projected_features
        }

# 动态图构建
class DynamicGraphBuilder:
    def __init__(self, device=device, knn_params=None):
        self.device = device
        
        if knn_params is None:
            knn_params = {
                'min_k': 1,
                'max_k': 10,
                'percentile': 30
            }
            
        self.cnn_knn = AdaptiveThresholdKNN(device=device, **knn_params)
        self.clip_knn = AdaptiveThresholdKNN(device=device, **knn_params)
        
    def build_graph(self, features, cnn_features, clip_features):
        num_nodes = features.shape[0]
        if num_nodes == 0:
            return torch.empty((2, 0), dtype=torch.long, device=self.device), torch.empty((0, 2), dtype=torch.float, device=self.device)
        
        cnn_features = check_nan_inf(cnn_features, "Graph CNN Features")
        clip_features = check_nan_inf(clip_features, "Graph CLIP Features")
        
        cnn_edge_index, cnn_edge_dist = self.cnn_knn(cnn_features)
        clip_edge_index, clip_edge_dist = self.clip_knn(clip_features)
        
        adj_matrix = torch.zeros(num_nodes, num_nodes, device=self.device)
        
        for i in range(cnn_edge_index.size(1)):
            src, dst = cnn_edge_index[0, i], cnn_edge_index[1, i]
            adj_matrix[src, dst] = torch.exp(-cnn_edge_dist[i, 0])
        
        for i in range(clip_edge_index.size(1)):
            src, dst = clip_edge_index[0, i], clip_edge_index[1, i]
            if adj_matrix[src, dst] > 0:
                adj_matrix[src, dst] = (adj_matrix[src, dst] + torch.exp(-clip_edge_dist[i, 0])) / 2
            else:
                adj_matrix[src, dst] = torch.exp(-clip_edge_dist[i, 0])
        
        edge_index = []
        edge_attr = []
        
        for i in range(num_nodes):
            for j in range(num_nodes):
                if i != j and adj_matrix[i, j] > 0:
                    edge_index.append([i, j])
                    cnn_sim = adj_matrix[i, j] if (cnn_edge_index[0] == i).any() and (cnn_edge_index[1] == j).any() else 0
                    clip_sim = adj_matrix[i, j] if (clip_edge_index[0] == i).any() and (clip_edge_index[1] == j).any() else 0
                    edge_attr.append([cnn_sim, clip_sim])
        
        if not edge_index:
            edge_index = [[i, i] for i in range(num_nodes)]
            edge_attr = [[1.0, 1.0] for _ in range(num_nodes)]
        
        edge_index = torch.tensor(edge_index, dtype=torch.long, device=self.device).t().contiguous()
        edge_attr = torch.tensor(edge_attr, dtype=torch.float, device=self.device)
        
        return edge_index, edge_attr

# 图神经网络模型
class GNNModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_classes, num_layers=2, num_heads=4):
        super().__init__()
        
        self.gat_layers = nn.ModuleList()
        self.bn_layers = nn.ModuleList()
        
        self.gat_layers.append(GATv2Conv(input_dim, hidden_dim, heads=num_heads, concat=True))
        self.bn_layers.append(nn.BatchNorm1d(hidden_dim * num_heads))
        
        for _ in range(num_layers - 1):
            self.gat_layers.append(GATv2Conv(hidden_dim * num_heads, hidden_dim, heads=num_heads, concat=True))
            self.bn_layers.append(nn.BatchNorm1d(hidden_dim * num_heads))
        
        self.out_proj = nn.Linear(hidden_dim * num_heads, output_dim)
        self.bn_out = nn.BatchNorm1d(output_dim)
        
        self.classifier = nn.Linear(output_dim, num_classes)
        
        self.projection_head = nn.Sequential(
            nn.Linear(output_dim, output_dim),
            nn.ReLU(),
            nn.Linear(output_dim, output_dim)
        )
        
        self.num_layers = num_layers
        self.num_heads = num_heads
        
    def forward(self, x, edge_index, edge_attr=None):
        x = check_nan_inf(x, "GNN Input Features")
        
        h = x
        for i in range(self.num_layers):
            h_prev = h
            if edge_index.numel() == 0:
                edge_index = torch.empty((2, 0), dtype=torch.long, device=x.device)
            
            h = self.gat_layers[i](h, edge_index)
            h = check_nan_inf(h, f"GNN Layer {i+1} Output")
            h = self.bn_layers[i](h)
            h = F.relu(h)
            if h.shape == h_prev.shape:
                h = h + h_prev
            h = F.dropout(h, p=0.5, training=self.training)
        
        h = self.out_proj(h)
        h = self.bn_out(h)
        h = F.relu(h)
        h = check_nan_inf(h, "Final Projected Features")
        
        batch = torch.arange(x.size(0), device=x.device)
        graph_repr = global_mean_pool(h, batch=batch)
        graph_repr = check_nan_inf(graph_repr, "Graph Representation")
        
        logits = self.classifier(graph_repr)
        logits = check_nan_inf(logits, "Classification Logits")
        
        contrastive_repr = self.projection_head(graph_repr)
        contrastive_repr = check_nan_inf(contrastive_repr, "Contrastive Representation")
        
        return {
            'node_features': h,
            'graph_repr': graph_repr,
            'logits': logits,
            'contrastive_repr': contrastive_repr
        }

# 对比学习损失
class ContrastiveLoss(nn.Module):
    def __init__(self, temperature=0.1):
        super().__init__()
        self.temperature = temperature
        self.criterion = nn.CrossEntropyLoss()
        
    def forward(self, features, labels=None):
        batch_size = features.size(0)
        features = check_nan_inf(features, "Contrastive Features")
        features_norm = F.normalize(features, p=2, dim=1)
        features_norm = check_nan_inf(features_norm, "Normalized Contrastive Features")
        
        sim_matrix = torch.matmul(features_norm, features_norm.transpose(0, 1)) / self.temperature
        sim_matrix = check_nan_inf(sim_matrix, "Contrastive Similarity Matrix")
        
        if labels is not None:
            labels_expanded = labels.expand(batch_size, batch_size)
            mask = (labels_expanded == labels_expanded.t()).float()
        else:
            mask = torch.zeros(batch_size, batch_size, device=features.device)
            for i in range(0, batch_size, 2):
                mask[i, i+1] = 1.0
                mask[i+1, i] = 1.0
        
        mask.fill_diagonal_(0)
        exp_sim = torch.exp(sim_matrix)
        exp_sim = check_nan_inf(exp_sim, "Exponential Similarity Matrix")
        
        mask_sum = mask.sum(1, keepdim=True)
        mask_sum = torch.max(mask_sum, torch.ones_like(mask_sum))
        denom = (exp_sim * (1 - torch.eye(batch_size, device=features.device))).sum(1, keepdim=True)
        denom = torch.clamp(denom, min=1e-10)
        
        log_prob = sim_matrix - torch.log(denom)
        log_prob = check_nan_inf(log_prob, "Log Probability Matrix")
        
        loss = - (mask * log_prob).sum(1) / mask_sum
        loss = loss.mean()
        loss = check_nan_inf(loss.unsqueeze(0), "Contrastive Loss")[0]
        
        return loss

# 训练函数
def train(model, feature_extractor, graph_builder, dataloader, criterion_cls, criterion_contrastive, 
          optimizer, device, epoch, config):
    model.train()
    feature_extractor.train()
    feature_extractor.clip_model.eval()
    
    total_loss = 0.0
    total_cls_loss = 0.0
    total_contrastive_loss = 0.0
    correct = 0
    total = 0
    
    for batch_idx, data in enumerate(dataloader):
        images = data['image'].to(device)
        labels = data['sub_label'].to(device)
        
        features_dict = feature_extractor(images)
        node_features = features_dict['projected_features']
        cnn_features = features_dict['cnn_features']
        clip_features = features_dict['clip_features']
        
        edge_index, edge_attr = graph_builder.build_graph(
            node_features, cnn_features, clip_features
        )
        
        output_dict = model(node_features, edge_index, edge_attr)
        logits = output_dict['logits']
        contrastive_repr = output_dict['contrastive_repr']
        
        cls_loss = criterion_cls(logits, labels)
        contrastive_loss = criterion_contrastive(contrastive_repr, labels)
        loss = cls_loss + config['contrastive_weight'] * contrastive_loss
        
        torch.nn.utils.clip_grad_norm_(feature_extractor.parameters(), max_norm=config['grad_clip'])
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=config['grad_clip'])
        
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        total_cls_loss += cls_loss.item()
        total_contrastive_loss += contrastive_loss.item()
        
        _, predicted = logits.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()
    
    avg_loss = total_loss / len(dataloader)
    avg_cls_loss = total_cls_loss / len(dataloader)
    avg_contrastive_loss = total_contrastive_loss / len(dataloader)
    accuracy = 100. * correct / total
    
    return avg_loss, avg_cls_loss, avg_contrastive_loss, accuracy

# 测试函数
def test(model, feature_extractor, graph_builder, dataloader, criterion, device, collect_predictions=False):
    model.eval()
    feature_extractor.eval()
    feature_extractor.clip_model.eval()
    
    test_loss = 0
    correct = 0
    total = 0
    
    all_labels = []
    all_predictions = []
    
    with torch.no_grad():
        for data in dataloader:
            images = data['image'].to(device)
            labels = data['sub_label'].to(device)
            
            features_dict = feature_extractor(images)
            node_features = features_dict['projected_features']
            cnn_features = features_dict['cnn_features']
            clip_features = features_dict['clip_features']
            
            edge_index, edge_attr = graph_builder.build_graph(
                node_features, cnn_features, clip_features
            )
            
            output_dict = model(node_features, edge_index, edge_attr)
            logits = output_dict['logits']
            
            loss = criterion(logits, labels)
            test_loss += loss.item()
            _, predicted = logits.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()
            
            if collect_predictions:
                all_labels.extend(labels.cpu().numpy())
                all_predictions.extend(predicted.cpu().numpy())
    
    avg_loss = test_loss / len(dataloader)
    accuracy = 100. * correct / total
    
    return avg_loss, accuracy, (all_labels, all_predictions) if collect_predictions else None

# 混淆矩阵可视化函数
def plot_confusion_matrix(y_true, y_pred, class_names, title="混淆矩阵", figsize=(12, 10), normalize=False):
    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
    
    cm = confusion_matrix(y_true, y_pred)
    
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        fmt = '.2f'
        title = f"{title} (归一化)"
    else:
        fmt = 'd'
        title = f"{title} (原始数量)"
    
    plt.figure(figsize=figsize)
    sns.set(font_scale=1.2)
    sns.heatmap(cm, annot=True, fmt=fmt, cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names,
                cbar=True, square=True)
    
    plt.xlabel('预测类别', fontsize=14)
    plt.ylabel('真实类别', fontsize=14)
    plt.title(title, fontsize=16)
    plt.tight_layout()
    
    filename = f"confusion_matrix_{'normalized' if normalize else 'raw'}.png"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"混淆矩阵图像已保存为: {filename}")
    
    plt.show()
    
    return cm

# 主函数（五折交叉验证）
def main():
    config = {
        "epochs": 100,
        "batch_size": 32,
        "feature_dim": 512,
        "hidden_dim": 128,
        "output_dim": 256,
        "lr": 0.0001,
        "weight_decay": 5e-4,
        "contrastive_weight": 0.1,
        "grad_clip": 1.0,
        "knn_params": {
            "min_k": 1,
            "max_k": 10,
            "percentile": 30
        },
        "n_folds": 5,
        "random_state": 42
    }

    # 数据变换
    train_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
    ])
    val_test_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    # 数据集路径
    full_data_path = r"D:\桌面\TrashNet数据集训练"  # 完整训练数据路径
    test_data_path = r"D:\桌面\TrashNet数据集测试"    # 独立测试集路径

    # 加载完整数据集（用于交叉验证）
    full_dataset = GarbageDataset(root_dir=full_data_path, transform=None, is_train=True)
    all_samples = full_dataset.samples
    all_labels = [label for (path, label) in all_samples]
    class_names = full_dataset.classes
    num_classes = len(class_names)

    # 保存类别顺序
    print("数据集类别顺序:", class_names)
    with open("classes.json", "w", encoding="utf-8") as f:
        json.dump(class_names, f, ensure_ascii=False, indent=2)

    # 初始化分层五折交叉验证
    skf = StratifiedKFold(n_splits=config["n_folds"], shuffle=True, random_state=config["random_state"])
    
    # 记录每一折的结果
    fold_results = {
        "train_accs": [],
        "val_accs": [],
        "train_losses": [],
        "val_losses": []
    }

    # 交叉验证循环
    for fold, (train_idx, val_idx) in enumerate(skf.split(all_samples, all_labels), 1):
        print(f"\n========== 开始第 {fold}/{config['n_folds']} 折训练 ==========")
        
        # 划分当前折的训练和验证样本
        train_samples = [all_samples[i] for i in train_idx]
        val_samples = [all_samples[i] for i in val_idx]
        
        # 创建数据集
        train_dataset = GarbageDataset(
            root_dir=full_data_path,
            transform=train_transform,
            is_train=True,
            samples=train_samples
        )
        val_dataset = GarbageDataset(
            root_dir=full_data_path,
            transform=val_test_transform,
            is_train=False,
            samples=val_samples
        )
        
        # 检查数据泄露
        train_paths = set([path for path, _ in train_samples])
        val_paths = set([path for path, _ in val_samples])
        intersection = train_paths & val_paths
        print(f"第 {fold} 折 - 训练集大小: {len(train_dataset)}, 验证集大小: {len(val_dataset)}")
        if len(intersection) > 0:
            print(f"[警告] 第 {fold} 折检测到数据泄露！重叠文件数: {len(intersection)}")
        else:
            print(f"[信息] 第 {fold} 折训练集与验证集无文件重叠")
        
        # 创建数据加载器
        train_loader = DataLoader(train_dataset, batch_size=config["batch_size"], shuffle=True, num_workers=4)
        val_loader = DataLoader(val_dataset, batch_size=config["batch_size"], shuffle=False, num_workers=4)
        
        # 重新初始化模型和特征提取器
        feature_extractor = FeatureExtractor(output_dim=config["feature_dim"]).to(device)
        graph_builder = DynamicGraphBuilder(device=device, knn_params=config["knn_params"])
        model = GNNModel(config["feature_dim"], config["hidden_dim"], config["output_dim"], 
                         num_classes=num_classes).to(device)

        # 损失函数和优化器
        criterion_cls = nn.CrossEntropyLoss()
        criterion_contrastive = ContrastiveLoss()

        optimizer = optim.Adam([
            {'params': feature_extractor.parameters(), 'lr': config["lr"]},
            {'params': model.parameters(), 'lr': config["lr"] * 2}
        ], weight_decay=config["weight_decay"])

        scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='min', factor=0.5, patience=5, verbose=True
        )

        # 当前折的最佳结果
        best_val_acc = 0.0
        best_val_loss = float('inf')
        
        # 训练当前折
        for epoch in range(config["epochs"]):
            train_loss, cls_loss, contrastive_loss, train_acc = train(
                model, feature_extractor, graph_builder, train_loader, 
                criterion_cls, criterion_contrastive, optimizer, device, epoch, config
            )
            val_loss, val_acc, _ = test(
                model, feature_extractor, graph_builder, val_loader, criterion_cls, device
            )
            scheduler.step(val_loss)
            
            # 更新最佳模型
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                best_val_loss = val_loss
                torch.save({
                    'fold': fold,
                    'epoch': epoch,
                    'feature_extractor': feature_extractor.state_dict(),
                    'model': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'best_val_acc': best_val_acc,
                    'best_val_loss': best_val_loss
                }, f'best_model_fold_{fold}.pth')
            
            # 打印进度
            if (epoch + 1) % 10 == 0:
                print(f'第 {fold} 折 - Epoch {epoch+1}/{config["epochs"]}, '
                      f'Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, '
                      f'Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.2f}%')
        
        # 记录当前折的最佳结果
        fold_results["train_accs"].append(train_acc)
        fold_results["val_accs"].append(best_val_acc)
        fold_results["train_losses"].append(train_loss)
        fold_results["val_losses"].append(best_val_loss)
        
        print(f"\n第 {fold} 折训练完成！")
        print(f"第 {fold} 折 - 最佳验证准确率: {best_val_acc:.2f}%, 最后训练准确率: {train_acc:.2f}%")

    # ========== 交叉验证结果统计 ==========
    print("\n========== 五折交叉验证结果统计 ==========")
    train_accs = fold_results["train_accs"]
    val_accs = fold_results["val_accs"]
    train_losses = fold_results["train_losses"]
    val_losses = fold_results["val_losses"]
    
    # 计算均值和标准差
    train_acc_mean = statistics.mean(train_accs)
    train_acc_std = statistics.stdev(train_accs) if len(train_accs) > 1 else 0.0
    
    val_acc_mean = statistics.mean(val_accs)
    val_acc_std = statistics.stdev(val_accs) if len(val_accs) > 1 else 0.0
    
    train_loss_mean = statistics.mean(train_losses)
    train_loss_std = statistics.stdev(train_losses) if len(train_losses) > 1 else 0.0
    
    val_loss_mean = statistics.mean(val_losses)
    val_loss_std = statistics.stdev(val_losses) if len(val_losses) > 1 else 0.0
    
    # 输出详细结果
    print("\n各折详细结果:")
    for i in range(config["n_folds"]):
        print(f"第 {i+1} 折 - 训练准确率: {train_accs[i]:.2f}%, 验证准确率: {val_accs[i]:.2f}%")
    
    # 输出统计结果
    print(f"\n======= 统计结果 =======")
    print(f"训练准确率 - 平均值: {train_acc_mean:.2f}%, 标准差: {train_acc_std:.4f}%")
    print(f"验证准确率 - 平均值: {val_acc_mean:.2f}%, 标准差: {val_acc_std:.4f}%")
    print(f"训练损失   - 平均值: {train_loss_mean:.4f}, 标准差: {train_loss_std:.4f}")
    print(f"验证损失   - 平均值: {val_loss_mean:.4f}, 标准差: {val_loss_std:.4f}")

    # ========== 独立测试集验证 ==========
    print("\n========== 独立测试集验证 ==========")
    best_fold_idx = val_accs.index(max(val_accs)) + 1
    print(f"最佳折为第 {best_fold_idx} 折，验证准确率: {max(val_accs):.2f}%")
    
    # 加载最佳模型
    best_checkpoint = torch.load(f'best_model_fold_{best_fold_idx}.pth', map_location=device)
    feature_extractor = FeatureExtractor(output_dim=config["feature_dim"]).to(device)
    model = GNNModel(config["feature_dim"], config["hidden_dim"], config["output_dim"], 
                     num_classes=num_classes).to(device)
    
    feature_extractor.load_state_dict(best_checkpoint['feature_extractor'])
    model.load_state_dict(best_checkpoint['model'])
    
    # 加载测试集
    test_dataset = GarbageDataset(root_dir=test_data_path, transform=val_test_transform, is_train=False)
    test_loader = DataLoader(test_dataset, batch_size=config["batch_size"], shuffle=False, num_workers=4)
    print(f"独立测试集大小: {len(test_dataset)}")
    
    # 测试
    test_loss, test_acc, (true_labels, pred_labels) = test(
        model, feature_extractor, graph_builder, test_loader, criterion_cls, device, collect_predictions=True
    )
    print(f"独立测试集准确率: {test_acc:.2f}%")
    
    # 生成评估报告
    print("\n独立测试集分类报告:")
    print(classification_report(true_labels, pred_labels, target_names=class_names, digits=4))
    
    # 混淆矩阵
    plot_confusion_matrix(true_labels, pred_labels, class_names, normalize=False)
    plot_confusion_matrix(true_labels, pred_labels, class_names, normalize=True)
    
    # 保存结果
    results = {
        "cross_validation": {
            "folds": config["n_folds"],
            "train_accs": train_accs,
            "val_accs": val_accs,
            "train_acc_mean": train_acc_mean,
            "train_acc_std": train_acc_std,
            "val_acc_mean": val_acc_mean,
            "val_acc_std": val_acc_std
        },
        "test_set": {
            "accuracy": test_acc,
            "loss": test_loss,
            "best_fold": best_fold_idx
        }
    }
    
    with open("cv_results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    # 保存最终模型
    torch.save({
        'feature_extractor': feature_extractor.state_dict(),
        'model': model.state_dict(),
        'cv_results': results,
        'test_acc': test_acc
    }, 'final_model_cv.pth')
    
    print("\n所有结果已保存，训练完成！")

if __name__ == "__main__":
    main()