# -*- coding: utf-8 -*-
"""
@author: Yuhang Yang
"""

import os
import json
import time
import random
import hashlib
import statistics
import numpy as np
from PIL import Image
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models

import clip
from sklearn.neighbors import kneighbors_graph
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report, confusion_matrix

import matplotlib.pyplot as plt
import seaborn as sns

from torch_geometric.nn import GATv2Conv


#1 Reproducibility
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_seed(42)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


#2 NaN/Inf checker
def check_nan_inf(tensor, name="Tensor"):
    has_nan = torch.isnan(tensor).any()
    has_inf = torch.isinf(tensor).any()
    if has_nan or has_inf:
        nan_count = torch.isnan(tensor).sum().item()
        inf_count = torch.isinf(tensor).sum().item()
        print(f"[Warning] {name} contains {nan_count} NaNs and {inf_count} Infs.")
        tensor = torch.nan_to_num(tensor, nan=0.0, posinf=1e6, neginf=-1e6)
        print(f"[Info] Replaced NaN/Inf in {name} with valid values.")
    return tensor


#3 Adaptive-threshold KNN
class AdaptiveThresholdKNN:
    def __init__(self, min_k=1, max_k=10, percentile=30, metric='euclidean', device='cpu'):
        self.min_k = min_k
        self.max_k = max_k
        self.percentile = percentile
        self.metric = metric
        self.device = device

    def compute_distances(self, features):
        n = features.shape[0]
        feats = features.detach().cpu().numpy()

        knn_graph = kneighbors_graph(
            feats,
            n_neighbors=min(self.max_k * 2, n - 1),
            mode='distance',
            metric=self.metric,
            include_self=False
        )
        return torch.tensor(knn_graph.toarray(), device=self.device)

    def compute_adaptive_threshold(self, distances):
        n = distances.shape[0]
        thresholds = torch.zeros(n, device=self.device)

        for i in range(n):
            d = distances[i]
            d_sorted = d[d > 0].sort()[0]
            if len(d_sorted) == 0:
                thresholds[i] = 1.0
                continue

            thr = torch.quantile(d_sorted, self.percentile / 100.0)
            cnt = torch.sum(d_sorted <= thr).item()

            if cnt < self.min_k:
                thr = d_sorted[self.min_k - 1] if len(d_sorted) >= self.min_k else d_sorted[-1]
            elif cnt > self.max_k:
                thr = d_sorted[self.max_k - 1]
            thresholds[i] = thr

        return thresholds

    def build_adjacency_matrix(self, distances, thresholds):
        n = distances.shape[0]
        adj = torch.zeros_like(distances)

        for i in range(n):
            thr = thresholds[i]
            neighbors = (distances[i] <= thr) & (distances[i] > 0)

            if neighbors.sum() > self.max_k:
                idx = torch.argsort(distances[i])[:self.max_k]
                adj[i, idx] = distances[i, idx]
            else:
                adj[i, neighbors] = distances[i, neighbors]

        # undirected
        adj = torch.max(adj, adj.t())
        return adj

    def __call__(self, features):
        distances = self.compute_distances(features)
        thresholds = self.compute_adaptive_threshold(distances)
        adj_dist = self.build_adjacency_matrix(distances, thresholds)

        # Convert dist-adj to edge list
        edge_index = []
        edge_dist = []
        n = adj_dist.shape[0]
        for i in range(n):
            for j in range(n):
                if i != j and adj_dist[i, j] > 0:
                    edge_index.append([i, j])
                    edge_dist.append([adj_dist[i, j]])

        if not edge_index:
            edge_index = [[i, i] for i in range(n)]
            edge_dist = [[1.0] for _ in range(n)]

        edge_index = torch.tensor(edge_index, dtype=torch.long, device=self.device).t().contiguous()
        edge_dist = torch.tensor(edge_dist, dtype=torch.float, device=self.device)
        return edge_index, edge_dist


#4 Dataset
class GarbageDataset(Dataset):
    def __init__(self, root_dir=None, transform=None, is_train=True, hide_semantic=True, samples=None):
        self.root_dir = root_dir
        self.transform = transform
        self.is_train = is_train
        self.hide_semantic = hide_semantic

        if root_dir:
            self.classes, self.class_to_idx = self._find_classes(root_dir)
        else:
            self.classes, self.class_to_idx = None, None

        if samples is not None:
            self.samples = samples
        elif root_dir:
            self.samples = self._make_dataset(root_dir, self.class_to_idx)
        else:
            self.samples = []

        # filename mapping (avoid semantic leakage in training)
        if self.is_train and self.hide_semantic:
            self.filename_mapping = {path: f"sample_{i}.jpg" for i, (path, _) in enumerate(self.samples)}
        else:
            self.filename_mapping = {path: f"{hashlib.md5(path.encode()).hexdigest()}.jpg" for path, _ in self.samples}

    def _find_classes(self, dir):
        classes = [d.name for d in os.scandir(dir) if d.is_dir()]
        classes.sort()
        class_to_idx = {cls_name: i for i, cls_name in enumerate(classes)}
        return classes, class_to_idx

    def _make_dataset(self, dir, class_to_idx):
        images = []
        dir = os.path.expanduser(dir)
        for target in sorted(class_to_idx.keys()):
            d = os.path.join(dir, target)
            if not os.path.isdir(d):
                continue
            for root, _, fnames in sorted(os.walk(d)):
                for fname in sorted(fnames):
                    if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                        path = os.path.join(root, fname)
                        try:
                            img = Image.open(path)
                            img.verify()
                            img.close()
                            images.append((path, class_to_idx[target]))
                        except Exception as e:
                            print(f"[Skip] Invalid image: {path}, Error: {e}")
        return images

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        image = Image.open(path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return {'image': image, 'sub_label': label, 'filename': self.filename_mapping[path]}


#5 Feature Extractor (ResNet50 + CLIP -> 512)
class FeatureExtractor(nn.Module):
    def __init__(self, visual_dim=2048, clip_dim=512, output_dim=512):
        super().__init__()
        cnn_model = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
        self.cnn = nn.Sequential(*list(cnn_model.children())[:-1])

        # freeze most CNN layers
        for p in list(self.cnn.parameters())[:-5]:
            p.requires_grad = False

        # CLIP
        self.clip_model, _ = clip.load("ViT-B/32", device=device)
        for p in self.clip_model.parameters():
            p.requires_grad = False

        self.projection = nn.Sequential(
            nn.Linear(visual_dim + clip_dim, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(),
            nn.Linear(1024, output_dim),
            nn.BatchNorm1d(output_dim)
        )

        self.clip_transform = transforms.Compose([
            transforms.Resize(224, interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.CenterCrop(224),
            transforms.Normalize((0.48145466, 0.4578275, 0.40821073),
                                 (0.26862954, 0.26130258, 0.27577711)),
        ])

    def extract_cnn_features(self, images):
        images = check_nan_inf(images, "CNN Input Images")
        feat = self.cnn(images).view(images.size(0), -1)
        feat = check_nan_inf(feat, "CNN Features")
        return feat

    def extract_clip_features(self, images):
        images = check_nan_inf(images, "CLIP Input Images")
        clip_input = self.clip_transform(images)
        clip_input = check_nan_inf(clip_input, "Processed CLIP Input")
        with torch.no_grad():
            clip_feat = self.clip_model.encode_image(clip_input)
        clip_feat = check_nan_inf(clip_feat.float(), "CLIP Features")
        return clip_feat

    def forward(self, images):
        images = check_nan_inf(images, "Input Images")
        cnn_feat = self.extract_cnn_features(images)
        clip_feat = self.extract_clip_features(images)
        comb = torch.cat([cnn_feat, clip_feat], dim=1)
        comb = check_nan_inf(comb, "Combined Features")
        proj = self.projection(comb)
        proj = check_nan_inf(proj, "Projected Features")
        return {
            'cnn_features': cnn_feat,
            'clip_features': clip_feat,
            'combined_features': comb,
            'projected_features': proj
        }


#6 Dynamic Graph Builder
class DynamicGraphBuilder:
    def __init__(self, device=device, knn_params=None, fuse_mode="mean"):
        self.device = device
        if knn_params is None:
            knn_params = {'min_k': 1, 'max_k': 10, 'percentile': 30}
        self.cnn_knn = AdaptiveThresholdKNN(device=device, **knn_params)
        self.clip_knn = AdaptiveThresholdKNN(device=device, **knn_params)
        self.fuse_mode = fuse_mode

    @staticmethod
    def _edge_list_to_sim_matrix(edge_index, edge_dist, n):
        # sim = exp(-dist)
        sim = torch.zeros(n, n, device=edge_index.device)
        if edge_index.numel() == 0:
            return sim
        s = torch.exp(-edge_dist[:, 0].clamp(min=0))
        sim[edge_index[0], edge_index[1]] = s
        return sim

    def build_graph(self, cnn_features, clip_features):
        n = cnn_features.shape[0]
        if n <= 1:
            # fallback self-loop
            edge_index = torch.tensor([[0], [0]], dtype=torch.long, device=self.device)
            edge_attr = torch.tensor([[1.0, 1.0]], dtype=torch.float, device=self.device)
            return edge_index, edge_attr

        cnn_features = check_nan_inf(cnn_features, "Graph CNN Features")
        clip_features = check_nan_inf(clip_features, "Graph CLIP Features")

        cnn_edge_index, cnn_edge_dist = self.cnn_knn(cnn_features)
        clip_edge_index, clip_edge_dist = self.clip_knn(clip_features)

        sim_cnn = self._edge_list_to_sim_matrix(cnn_edge_index, cnn_edge_dist, n)
        sim_clip = self._edge_list_to_sim_matrix(clip_edge_index, clip_edge_dist, n)

        # undirected symmetrize
        sim_cnn = torch.max(sim_cnn, sim_cnn.t())
        sim_clip = torch.max(sim_clip, sim_clip.t())

        if self.fuse_mode == "sum":
            adj = sim_cnn + sim_clip
        else:
            adj = 0.5 * (sim_cnn + sim_clip)

        # Build final edge list from fused adjacency
        src, dst = torch.where(adj > 0)
        mask = src != dst
        src = src[mask]
        dst = dst[mask]

        if src.numel() == 0:
            # fallback self-loops
            edge_index = torch.stack([torch.arange(n, device=self.device),
                                      torch.arange(n, device=self.device)], dim=0)
            edge_attr = torch.ones(n, 2, device=self.device)
            return edge_index, edge_attr

        edge_index = torch.stack([src, dst], dim=0).long()
        e_cnn = sim_cnn[src, dst].unsqueeze(1)
        e_clip = sim_clip[src, dst].unsqueeze(1)
        edge_attr = torch.cat([e_cnn, e_clip], dim=1).float()
        edge_attr = check_nan_inf(edge_attr, "Edge Attr")
        return edge_index, edge_attr


#7 Edge-aware GATv2 Model (Node-level classification)
class GNNModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_classes, num_layers=2, num_heads=4, edge_dim=2):
        super().__init__()
        self.num_layers = num_layers

        self.gat_layers = nn.ModuleList()
        self.bn_layers = nn.ModuleList()

        self.gat_layers.append(GATv2Conv(input_dim, hidden_dim, heads=num_heads, concat=True, edge_dim=edge_dim))
        self.bn_layers.append(nn.BatchNorm1d(hidden_dim * num_heads))

        for _ in range(num_layers - 1):
            self.gat_layers.append(GATv2Conv(hidden_dim * num_heads, hidden_dim, heads=num_heads, concat=True, edge_dim=edge_dim))
            self.bn_layers.append(nn.BatchNorm1d(hidden_dim * num_heads))

        self.classifier = nn.Linear(hidden_dim * num_heads, num_classes)

        # contrastive head (optional)
        self.projection_head = nn.Sequential(
            nn.Linear(hidden_dim * num_heads, hidden_dim * num_heads),
            nn.ReLU(),
            nn.Linear(hidden_dim * num_heads, hidden_dim * num_heads)
        )

    def forward(self, x, edge_index, edge_attr):
        x = check_nan_inf(x, "GNN Input Features")
        h = x

        for i in range(self.num_layers):
            h_prev = h
            h = self.gat_layers[i](h, edge_index, edge_attr=edge_attr)
            h = check_nan_inf(h, f"GATv2 Layer {i+1} Output")
            h = self.bn_layers[i](h)
            h = F.relu(h)
            if h.shape == h_prev.shape:
                h = h + h_prev
            h = F.dropout(h, p=0.5, training=self.training)

        logits = self.classifier(h)  # node-level classification
        logits = check_nan_inf(logits, "Classification Logits")

        contrastive_repr = self.projection_head(h)
        contrastive_repr = check_nan_inf(contrastive_repr, "Contrastive Representation")

        return {'logits': logits, 'contrastive_repr': contrastive_repr, 'node_features': h}


#8 Contrastive Loss
class ContrastiveLoss(nn.Module):
    def __init__(self, temperature=0.1):
        super().__init__()
        self.temperature = temperature

    def forward(self, features, labels=None):
        b = features.size(0)
        features = check_nan_inf(features, "Contrastive Features")
        feats = F.normalize(features, p=2, dim=1)
        feats = check_nan_inf(feats, "Normalized Contrastive Features")

        sim = (feats @ feats.t()) / self.temperature
        sim = check_nan_inf(sim, "Contrastive Similarity Matrix")

        if labels is not None:
            lbl = labels.unsqueeze(1)
            mask = (lbl == lbl.t()).float()
        else:
            mask = torch.zeros_like(sim)

        mask.fill_diagonal_(0)
        exp_sim = torch.exp(sim)
        denom = (exp_sim * (1 - torch.eye(b, device=features.device))).sum(1, keepdim=True).clamp(min=1e-10)
        log_prob = sim - torch.log(denom)
        loss = -(mask * log_prob).sum(1) / (mask.sum(1).clamp(min=1))
        return loss.mean()


#9 Train/Test
def train_one_epoch(model, fe, gb, loader, crit_cls, crit_con, optimizer, device, config):
    model.train()
    fe.train()
    fe.clip_model.eval()

    total_loss = 0.0
    total_cls = 0.0
    total_con = 0.0
    correct = 0
    total = 0

    for data in loader:
        images = data['image'].to(device)
        labels = data['sub_label'].to(device)

        feats = fe(images)
        node_x = feats['projected_features']
        cnn_f = feats['cnn_features']
        clip_f = feats['clip_features']

        edge_index, edge_attr = gb.build_graph(cnn_f, clip_f)
        out = model(node_x, edge_index, edge_attr)

        logits = out['logits']
        con_repr = out['contrastive_repr']

        cls_loss = crit_cls(logits, labels)
        con_loss = crit_con(con_repr, labels)
        loss = cls_loss + config['contrastive_weight'] * con_loss

        torch.nn.utils.clip_grad_norm_(fe.parameters(), config['grad_clip'])
        torch.nn.utils.clip_grad_norm_(model.parameters(), config['grad_clip'])

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        total_cls += cls_loss.item()
        total_con += con_loss.item()

        pred = logits.argmax(1)
        correct += pred.eq(labels).sum().item()
        total += labels.size(0)

    return total_loss / len(loader), total_cls / len(loader), total_con / len(loader), 100.0 * correct / total


@torch.no_grad()
def eval_one_epoch(model, fe, gb, loader, crit_cls, device, collect=False):
    model.eval()
    fe.eval()
    fe.clip_model.eval()

    total_loss = 0.0
    correct = 0
    total = 0
    ys, ps = [], []

    for data in loader:
        images = data['image'].to(device)
        labels = data['sub_label'].to(device)

        feats = fe(images)
        node_x = feats['projected_features']
        cnn_f = feats['cnn_features']
        clip_f = feats['clip_features']

        edge_index, edge_attr = gb.build_graph(cnn_f, clip_f)
        out = model(node_x, edge_index, edge_attr)
        logits = out['logits']

        loss = crit_cls(logits, labels)
        total_loss += loss.item()

        pred = logits.argmax(1)
        correct += pred.eq(labels).sum().item()
        total += labels.size(0)

        if collect:
            ys.extend(labels.cpu().tolist())
            ps.extend(pred.cpu().tolist())

    return total_loss / len(loader), 100.0 * correct / total, (ys, ps) if collect else None


#10 Confusion Matrix
def plot_confusion_matrix(y_true, y_pred, class_names, title="Confusion Matrix", figsize=(12, 10), normalize=False):
    plt.rcParams["font.family"] = ["SimHei", "Arial Unicode MS", "DejaVu Sans"]
    cm = confusion_matrix(y_true, y_pred)

    if normalize:
        cm = cm.astype('float') / (cm.sum(axis=1, keepdims=True) + 1e-12)
        fmt = '.2f'
        title = f"{title} (Normalized)"
    else:
        fmt = 'd'
        title = f"{title} (Counts)"

    plt.figure(figsize=figsize)
    sns.set(font_scale=1.2)
    sns.heatmap(cm, annot=True, fmt=fmt, cmap='Blues',
                xticklabels=class_names, yticklabels=class_names,
                cbar=True, square=True)
    plt.xlabel('Predicted Label', fontsize=14)
    plt.ylabel('True Label', fontsize=14)
    plt.title(title, fontsize=16)
    plt.tight_layout()

    filename = f"confusion_matrix_{'normalized' if normalize else 'raw'}.png"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"[Info] Confusion matrix figure saved as: {filename}")
    plt.show()
    return cm


#11 Main
def main():
    config = {
        "epochs": 100,
        "batch_size": 32,
        "feature_dim": 512,
        "hidden_dim": 128,
        "lr": 1e-4,
        "weight_decay": 5e-4,
        "contrastive_weight": 0.1,
        "grad_clip": 1.0,
        "knn_params": {"min_k": 1, "max_k": 10, "percentile": 30},
        "n_folds": 5,
        "random_state": 42
    }

    train_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
    ])
    val_test_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    # ====== CHANGE PATHS HERE ======
    full_data_path = r"D:\桌面\TrashNet数据集训练"
    test_data_path = r"D:\桌面\TrashNet数据集测试"

    # Load full dataset list for CV split
    full_dataset = GarbageDataset(root_dir=full_data_path, transform=None, is_train=True)
    all_samples = full_dataset.samples
    all_labels = [label for (_, label) in all_samples]
    class_names = full_dataset.classes
    num_classes = len(class_names)

    print("Class order in the dataset:", class_names)
    with open("classes.json", "w", encoding="utf-8") as f:
        json.dump(class_names, f, ensure_ascii=False, indent=2)

    skf = StratifiedKFold(n_splits=config["n_folds"], shuffle=True, random_state=config["random_state"])

    fold_results = {"train_accs": [], "val_accs": [], "train_losses": [], "val_losses": []}

    for fold, (train_idx, val_idx) in enumerate(skf.split(all_samples, all_labels), 1):
        print(f"\n========== Start Fold {fold}/{config['n_folds']} ==========")

        train_samples = [all_samples[i] for i in train_idx]
        val_samples = [all_samples[i] for i in val_idx]

        train_dataset = GarbageDataset(
            root_dir=full_data_path, transform=train_transform, is_train=True, samples=train_samples
        )
        val_dataset = GarbageDataset(
            root_dir=full_data_path, transform=val_test_transform, is_train=False, samples=val_samples
        )

        train_loader = DataLoader(train_dataset, batch_size=config["batch_size"], shuffle=True, num_workers=4)
        val_loader = DataLoader(val_dataset, batch_size=config["batch_size"], shuffle=False, num_workers=4)

        # init per-fold
        feature_extractor = FeatureExtractor(output_dim=config["feature_dim"]).to(device)
        graph_builder = DynamicGraphBuilder(device=device, knn_params=config["knn_params"], fuse_mode="mean")
        model = GNNModel(
            input_dim=config["feature_dim"],
            hidden_dim=config["hidden_dim"],
            num_classes=num_classes,
            num_layers=2,
            num_heads=4,
            edge_dim=2
        ).to(device)

        crit_cls = nn.CrossEntropyLoss()
        crit_con = ContrastiveLoss()

        optimizer = optim.Adam(
            [{'params': feature_extractor.parameters(), 'lr': config["lr"]},
             {'params': model.parameters(), 'lr': config["lr"] * 2}],
            weight_decay=config["weight_decay"]
        )
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='min', factor=0.5, patience=5, verbose=True
        )

        best_val_acc = 0.0
        best_val_loss = float('inf')

        for epoch in range(config["epochs"]):
            tr_loss, tr_cls, tr_con, tr_acc = train_one_epoch(
                model, feature_extractor, graph_builder, train_loader,
                crit_cls, crit_con, optimizer, device, config
            )
            va_loss, va_acc, _ = eval_one_epoch(
                model, feature_extractor, graph_builder, val_loader,
                crit_cls, device, collect=False
            )
            scheduler.step(va_loss)

            if va_acc > best_val_acc:
                best_val_acc = va_acc
                best_val_loss = va_loss
                torch.save({
                    'fold': fold,
                    'epoch': epoch,
                    'feature_extractor': feature_extractor.state_dict(),
                    'model': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'best_val_acc': best_val_acc,
                    'best_val_loss': best_val_loss
                }, f'best_model_fold_{fold}.pth')

            # print every epoch (you can change to every 10 epochs if you want)
            print(f"Fold {fold} | Epoch {epoch+1}/{config['epochs']}, "
                  f"Train L:{tr_loss:.4f} (Cls:{tr_cls:.4f},Con:{tr_con:.4f}), "
                  f"Train Acc:{tr_acc:.2f}%, Val L:{va_loss:.4f}, Val Acc:{va_acc:.2f}%")

        fold_results["train_accs"].append(tr_acc)
        fold_results["val_accs"].append(best_val_acc)
        fold_results["train_losses"].append(tr_loss)
        fold_results["val_losses"].append(best_val_loss)

        print(f"\nFold {fold} finished! Best Val Acc: {best_val_acc:.2f}%")

    # ===== CV Summary =====
    print("\n========== 5-Fold Cross-Validation Summary ==========")
    train_accs = fold_results["train_accs"]
    val_accs = fold_results["val_accs"]
    train_losses = fold_results["train_losses"]
    val_losses = fold_results["val_losses"]

    train_acc_mean = statistics.mean(train_accs)
    train_acc_std = statistics.stdev(train_accs) if len(train_accs) > 1 else 0.0
    val_acc_mean = statistics.mean(val_accs)
    val_acc_std = statistics.stdev(val_accs) if len(val_accs) > 1 else 0.0

    print(f"Train Acc - Mean: {train_acc_mean:.2f}%, Std: {train_acc_std:.4f}%")
    print(f"Val Acc   - Mean: {val_acc_mean:.2f}%, Std: {val_acc_std:.4f}%")

    # ===== Independent Test Set =====
    print("\n========== Independent Test Set Evaluation ==========")
    best_fold_idx = val_accs.index(max(val_accs)) + 1
    print(f"Best fold: Fold {best_fold_idx}, Best Val Acc: {max(val_accs):.2f}%")

    best_checkpoint = torch.load(f'best_model_fold_{best_fold_idx}.pth', map_location=device)

    feature_extractor = FeatureExtractor(output_dim=config["feature_dim"]).to(device)
    model = GNNModel(
        input_dim=config["feature_dim"],
        hidden_dim=config["hidden_dim"],
        num_classes=num_classes,
        num_layers=2,
        num_heads=4,
        edge_dim=2
    ).to(device)

    feature_extractor.load_state_dict(best_checkpoint['feature_extractor'])
    model.load_state_dict(best_checkpoint['model'])

    test_dataset = GarbageDataset(root_dir=test_data_path, transform=val_test_transform, is_train=False)
    test_loader = DataLoader(test_dataset, batch_size=config["batch_size"], shuffle=False, num_workers=4)
    print(f"Independent test set size: {len(test_dataset)}")

    test_loss, test_acc, (true_labels, pred_labels) = eval_one_epoch(
        model, feature_extractor, graph_builder, test_loader,
        nn.CrossEntropyLoss(), device, collect=True
    )
    print(f"Independent test set accuracy: {test_acc:.2f}%")

    print("\nIndependent test set classification report:")
    print(classification_report(true_labels, pred_labels, target_names=class_names, digits=4))

    plot_confusion_matrix(true_labels, pred_labels, class_names, normalize=False)
    plot_confusion_matrix(true_labels, pred_labels, class_names, normalize=True)

    results = {
        "cross_validation": {
            "folds": config["n_folds"],
            "train_accs": train_accs,
            "val_accs": val_accs,
            "train_acc_mean": train_acc_mean,
            "train_acc_std": train_acc_std,
            "val_acc_mean": val_acc_mean,
            "val_acc_std": val_acc_std
        },
        "test_set": {
            "accuracy": test_acc,
            "loss": float(test_loss),
            "best_fold": best_fold_idx
        }
    }

    with open("cv_results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    torch.save({
        'feature_extractor': feature_extractor.state_dict(),
        'model': model.state_dict(),
        'cv_results': results,
        'test_acc': test_acc
    }, 'final_model_cv.pth')

    print("\nAll results saved. Training completed!")


if __name__ == "__main__":
    main()
