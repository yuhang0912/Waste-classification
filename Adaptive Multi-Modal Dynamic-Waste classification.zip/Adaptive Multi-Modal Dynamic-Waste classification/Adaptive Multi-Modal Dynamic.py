# -*- coding: utf-8 -*-
"""
Created on Tue Jun 17 15:35:28 2025
@author: Yuhang Yang

"""

import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
import clip
from PIL import Image
import numpy as np
import random
from torch_geometric.nn import GATv2Conv, global_mean_pool
from torch_geometric.data import Data, DataLoader as GeoDataLoader
from sklearn.neighbors import kneighbors_graph
import hashlib  # 用于生成文件哈希值
import time
from tqdm import tqdm
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns


# 设置随机种子确保结果可复现
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

set_seed(42)

# 设备配置
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


# 特征验证工具函数
def check_nan_inf(tensor, name="Tensor"):
    """检查张量中是否有NaN或Inf值"""
    has_nan = torch.isnan(tensor).any()
    has_inf = torch.isinf(tensor).any()

    if has_nan or has_inf:
        # 记录异常值的位置和数量
        nan_count = torch.isnan(tensor).sum().item()
        inf_count = torch.isinf(tensor).sum().item()

        # 找到第一个NaN和Inf的位置
        if has_nan:
            nan_indices = torch.nonzero(torch.isnan(tensor))[0].tolist()
        if has_inf:
            inf_indices = torch.nonzero(torch.isinf(tensor))[0].tolist()

        print(f"警告: {name} 包含 {nan_count} 个NaN和 {inf_count} 个Inf")

        # 用小值替换NaN和Inf
        tensor = torch.nan_to_num(tensor, nan=0.0, posinf=1e6, neginf=-1e6)
        print(f"已将 {name} 中的NaN/Inf替换为有效值")

    return tensor


# 自适应阈值KNN算法
class AdaptiveThresholdKNN:
    def __init__(self, min_k=1, max_k=10, percentile=30, metric='euclidean', device='cpu'):
        """
        自适应阈值KNN算法

        参数:
            min_k: 每个节点的最小邻居数
            max_k: 每个节点的最大邻居数
            percentile: 初始阈值的百分位数
            metric: 距离度量方式
            device: 计算设备
        """
        self.min_k = min_k
        self.max_k = max_k
        self.percentile = percentile
        self.metric = metric
        self.device = device

    def compute_distances(self, features):
        """计算特征之间的距离矩阵"""
        n = features.shape[0]
        features = features.detach().cpu().numpy()

        # 使用sklearn计算KNN图
        knn_graph = kneighbors_graph(
            features,
            n_neighbors=min(self.max_k * 2, n - 1),  # 计算更多邻居以获取完整距离分布
            mode='distance',
            metric=self.metric,
            include_self=False
        )

        return torch.tensor(knn_graph.toarray(), device=self.device)

    def compute_adaptive_threshold(self, distances):
        """为每个节点计算自适应距离阈值"""
        n = distances.shape[0]
        thresholds = torch.zeros(n, device=self.device)

        for i in range(n):
            # 获取当前节点到其他所有节点的距离
            node_distances = distances[i]

            # 移除自身距离(0)并排序
            node_distances = node_distances[node_distances > 0].sort()[0]

            if len(node_distances) == 0:
                # 如果没有邻居，设置一个默认阈值
                thresholds[i] = 1.0
                continue

            # 计算初始阈值：基于指定百分位数
            threshold = torch.quantile(node_distances, self.percentile / 100.0)

            # 计算在此阈值下的邻居数
            neighbors_count = torch.sum(node_distances <= threshold).item()

            # 调整阈值以满足min_k和max_k约束
            if neighbors_count < self.min_k:
                # 邻居太少，增加阈值
                if len(node_distances) >= self.min_k:
                    threshold = node_distances[self.min_k - 1]
                else:
                    threshold = node_distances[-1]  # 取最大可能距离
            elif neighbors_count > self.max_k:
                # 邻居太多，减少阈值
                threshold = node_distances[self.max_k - 1]

            thresholds[i] = threshold

        return thresholds

    def build_adjacency_matrix(self, distances, thresholds):
        """构建邻接矩阵"""
        n = distances.shape[0]
        adj_matrix = torch.zeros_like(distances)

        for i in range(n):
            # 获取当前节点的阈值
            threshold = thresholds[i]

            # 找到所有距离小于等于阈值的节点
            neighbors = (distances[i] <= threshold) & (distances[i] > 0)

            # 应用最大邻居数约束
            if neighbors.sum() > self.max_k:
                # 选择距离最近的max_k个邻居
                top_k_indices = torch.argsort(distances[i])[:self.max_k]
                adj_matrix[i, top_k_indices] = distances[i, top_k_indices]
            else:
                adj_matrix[i, neighbors] = distances[i, neighbors]

        # 转换为无向图
        adj_matrix = torch.max(adj_matrix, adj_matrix.t())

        return adj_matrix

    def __call__(self, features):
        """执行自适应阈值KNN算法"""
        # 计算距离矩阵
        distances = self.compute_distances(features)

        # 计算自适应阈值
        thresholds = self.compute_adaptive_threshold(distances)

        # 构建邻接矩阵
        adj_matrix = self.build_adjacency_matrix(distances, thresholds)

        # 构建边索引和边属性
        edge_index = []
        edge_attr = []

        for i in range(adj_matrix.shape[0]):
            for j in range(adj_matrix.shape[1]):
                if i != j and adj_matrix[i, j] > 0:
                    edge_index.append([i, j])
                    edge_attr.append([adj_matrix[i, j]])

        # 处理空边情况
        if not edge_index:
            edge_index = [[i, i] for i in range(adj_matrix.shape[0])]
            edge_attr = [[1.0] for _ in range(adj_matrix.shape[0])]

        edge_index = torch.tensor(edge_index, dtype=torch.long, device=self.device).t().contiguous()
        edge_attr = torch.tensor(edge_attr, dtype=torch.float, device=self.device)

        return edge_index, edge_attr


# 数据加载与预处理 - 增强版，防止标签特征泄露
class GarbageDataset(Dataset):
    def __init__(self, root_dir, transform=None, is_train=True, hide_semantic=True):
        self.root_dir = root_dir
        self.transform = transform
        self.is_train = is_train
        self.hide_semantic = hide_semantic
        self.classes, self.class_to_idx = self._find_classes(self.root_dir)
        self.samples = self._make_dataset(self.root_dir, self.class_to_idx)

        # 为训练集生成随机文件名映射，防止语义信息泄露
        if self.is_train and self.hide_semantic:
            self.filename_mapping = {path: f"sample_{i}.jpg" for i, (path, _) in enumerate(self.samples)}
        else:
            # 测试集使用文件哈希值作为文件名，避免语义信息
            self.filename_mapping = {path: f"{hashlib.md5(path.encode()).hexdigest()}.jpg" for path, _ in self.samples}

    def _find_classes(self, dir):
        classes = [d.name for d in os.scandir(dir) if d.is_dir()]
        classes.sort()
        class_to_idx = {cls_name: i for i, cls_name in enumerate(classes)}
        return classes, class_to_idx

    def _make_dataset(self, dir, class_to_idx):
        images = []
        dir = os.path.expanduser(dir)
        for target in sorted(class_to_idx.keys()):
            d = os.path.join(dir, target)
            if not os.path.isdir(d):
                continue
            for root, _, fnames in sorted(os.walk(d)):
                for fname in sorted(fnames):
                    if fname.endswith(('.jpg', '.jpeg', '.png')):
                        path = os.path.join(root, fname)
                        # 检查图像文件是否有效
                        try:
                            img = Image.open(path)
                            img.verify()
                            img.close()
                            item = (path, class_to_idx[target])
                            images.append(item)
                        except Exception as e:
                            print(f"跳过无效图像: {path}, 错误: {e}")
        return images

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        image = Image.open(path).convert('RGB')

        if self.transform:
            image = self.transform(image)

        # 不返回任何可能包含语义信息的字段
        return {
            'image': image,
            'sub_label': label,
            'filename': self.filename_mapping[path]  # 返回随机生成的文件名，而非原始文件名
        }


# 数据泄露检查函数
def check_data_leakage(train_dataset, test_dataset):
    """检查训练集与测试集是否存在文件路径重叠"""
    train_files = set(os.path.basename(path) for path, _ in train_dataset.samples)
    test_files = set(os.path.basename(path) for path, _ in test_dataset.samples)
    intersection = train_files & test_files

    if len(intersection) > 0:
        print("[警告] 检测到数据泄露！以下文件同时存在于训练集和测试集:")
        for fname in intersection:
            print(f" - {fname}")
        return True
    else:
        print("[信息] 训练集与测试集无文件重叠，数据划分正常")
        return False


# 特征提取器 - 移除任何可能的语义信息依赖
class FeatureExtractor(nn.Module):
    def __init__(self, visual_dim=2048, clip_dim=512, output_dim=512):
        super().__init__()

        # 加载预训练的CNN模型 (ResNet50)
        cnn_model = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
        modules = list(cnn_model.children())[:-1]  # 去掉最后的全连接层
        self.cnn = nn.Sequential(*modules)

        # 冻结CNN的大部分参数，只微调最后几层
        for param in list(self.cnn.parameters())[:-5]:
            param.requires_grad = False

        # 加载预训练的CLIP模型
        self.clip_model, self.clip_preprocess = clip.load("ViT-B/32", device=device)

        # 冻结CLIP模型的所有参数
        for param in self.clip_model.parameters():
            param.requires_grad = False

        # 特征融合与降维
        self.projection = nn.Sequential(
            nn.Linear(visual_dim + clip_dim, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(),
            nn.Linear(1024, output_dim),
            nn.BatchNorm1d(output_dim)
        )

        self.visual_dim = visual_dim
        self.clip_dim = clip_dim

        # CLIP图像预处理转换
        self.clip_transform = transforms.Compose([
            transforms.Resize(224, interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.CenterCrop(224),
            transforms.Normalize((0.48145466, 0.4578275, 0.40821073), (0.26862954, 0.26130258, 0.27577711)),
        ])

    def extract_cnn_features(self, images):
        images = check_nan_inf(images, "CNN Input Images")
        features = self.cnn(images)
        features = features.view(features.size(0), -1)
        features = check_nan_inf(features, "CNN Features")
        return features

    def extract_clip_features(self, images):
        images = check_nan_inf(images, "CLIP Input Images")
        clip_input = self.clip_transform(images)
        clip_input = check_nan_inf(clip_input, "Processed CLIP Input")

        with torch.no_grad():
            clip_features = self.clip_model.encode_image(clip_input)

        clip_features = clip_features.float()
        clip_features = check_nan_inf(clip_features, "CLIP Features")
        return clip_features

    def forward(self, images):
        images = check_nan_inf(images, "Input Images")
        cnn_features = self.extract_cnn_features(images)
        clip_features = self.extract_clip_features(images)
        combined_features = torch.cat([cnn_features, clip_features], dim=1)
        combined_features = check_nan_inf(combined_features, "Combined Features")
        projected_features = self.projection(combined_features)
        projected_features = check_nan_inf(projected_features, "Projected Features")

        return {
            'cnn_features': cnn_features,
            'clip_features': clip_features,
            'combined_features': combined_features,
            'projected_features': projected_features
        }


# 动态图构建 - 使用自适应阈值KNN
class DynamicGraphBuilder:
    def __init__(self, device=device, knn_params=None):
        self.device = device

        # 自适应KNN参数
        if knn_params is None:
            knn_params = {
                'min_k': 1,
                'max_k': 10,
                'percentile': 30
            }

        self.cnn_knn = AdaptiveThresholdKNN(device=device, **knn_params)
        self.clip_knn = AdaptiveThresholdKNN(device=device, **knn_params)

    def build_graph(self, features, cnn_features, clip_features):
        """构建多视角图，使用自适应阈值KNN"""
        num_nodes = features.shape[0]
        if num_nodes == 0:
            return torch.empty((2, 0), dtype=torch.long, device=self.device), torch.empty((0, 2), dtype=torch.float,
                                                                                          device=self.device)

        # 确保特征没有NaN/Inf
        cnn_features = check_nan_inf(cnn_features, "Graph CNN Features")
        clip_features = check_nan_inf(clip_features, "Graph CLIP Features")

        # 1. 使用自适应KNN构建CNN特征图
        cnn_edge_index, cnn_edge_dist = self.cnn_knn(cnn_features)

        # 2. 使用自适应KNN构建CLIP特征图
        clip_edge_index, clip_edge_dist = self.clip_knn(clip_features)

        # 3. 构建组合邻接矩阵
        adj_matrix = torch.zeros(num_nodes, num_nodes, device=self.device)

        # 添加CNN边
        for i in range(cnn_edge_index.size(1)):
            src, dst = cnn_edge_index[0, i], cnn_edge_index[1, i]
            adj_matrix[src, dst] = torch.exp(-cnn_edge_dist[i, 0])  # 转换为相似度

        # 添加CLIP边
        for i in range(clip_edge_index.size(1)):
            src, dst = clip_edge_index[0, i], clip_edge_index[1, i]
            # 如果已经有CNN边，取平均值；否则直接添加
            if adj_matrix[src, dst] > 0:
                adj_matrix[src, dst] = (adj_matrix[src, dst] + torch.exp(-clip_edge_dist[i, 0])) / 2
            else:
                adj_matrix[src, dst] = torch.exp(-clip_edge_dist[i, 0])

        # 4. 构建最终边索引和边属性
        edge_index = []
        edge_attr = []

        for i in range(num_nodes):
            for j in range(num_nodes):
                if i != j and adj_matrix[i, j] > 0:
                    edge_index.append([i, j])
                    # 边属性：[CNN相似度, CLIP相似度]
                    cnn_sim = adj_matrix[i, j] if (cnn_edge_index[0] == i).any() and (
                                cnn_edge_index[1] == j).any() else 0
                    clip_sim = adj_matrix[i, j] if (clip_edge_index[0] == i).any() and (
                                clip_edge_index[1] == j).any() else 0
                    edge_attr.append([cnn_sim, clip_sim])

        # 处理空边情况
        if not edge_index:
            edge_index = [[i, i] for i in range(num_nodes)]
            edge_attr = [[1.0, 1.0] for _ in range(num_nodes)]

        edge_index = torch.tensor(edge_index, dtype=torch.long, device=self.device).t().contiguous()
        edge_attr = torch.tensor(edge_attr, dtype=torch.float, device=self.device)

        return edge_index, edge_attr


# 图神经网络模型
class GNNModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_classes, num_layers=2, num_heads=4):
        super().__init__()

        self.gat_layers = nn.ModuleList()
        self.bn_layers = nn.ModuleList()

        # 输入层
        self.gat_layers.append(GATv2Conv(input_dim, hidden_dim, heads=num_heads, concat=True))
        self.bn_layers.append(nn.BatchNorm1d(hidden_dim * num_heads))

        # 隐藏层
        for _ in range(num_layers - 1):
            self.gat_layers.append(GATv2Conv(hidden_dim * num_heads, hidden_dim, heads=num_heads, concat=True))
            self.bn_layers.append(nn.BatchNorm1d(hidden_dim * num_heads))

        # 输出层
        self.out_proj = nn.Linear(hidden_dim * num_heads, output_dim)
        self.bn_out = nn.BatchNorm1d(output_dim)

        # 分类器
        self.classifier = nn.Linear(output_dim, num_classes)

        # 对比学习投影头
        self.projection_head = nn.Sequential(
            nn.Linear(output_dim, output_dim),
            nn.ReLU(),
            nn.Linear(output_dim, output_dim)
        )

        self.num_layers = num_layers
        self.num_heads = num_heads

    def forward(self, x, edge_index, edge_attr=None):
        x = check_nan_inf(x, "GNN Input Features")

        # GNN层前向传播
        h = x
        for i in range(self.num_layers):
            h_prev = h
            if edge_index.numel() == 0:
                edge_index = torch.empty((2, 0), dtype=torch.long, device=x.device)

            h = self.gat_layers[i](h, edge_index)
            h = check_nan_inf(h, f"GNN Layer {i + 1} Output")
            h = self.bn_layers[i](h)
            h = F.relu(h)
            if h.shape == h_prev.shape:
                h = h + h_prev
            h = F.dropout(h, p=0.5, training=self.training)

        # 最终投影
        h = self.out_proj(h)
        h = self.bn_out(h)
        h = F.relu(h)
        h = check_nan_inf(h, "Final Projected Features")

        # 图级表示
        batch = torch.arange(x.size(0), device=x.device)
        graph_repr = global_mean_pool(h, batch=batch)
        graph_repr = check_nan_inf(graph_repr, "Graph Representation")

        # 分类预测
        logits = self.classifier(graph_repr)
        logits = check_nan_inf(logits, "Classification Logits")

        # 对比学习表示
        contrastive_repr = self.projection_head(graph_repr)
        contrastive_repr = check_nan_inf(contrastive_repr, "Contrastive Representation")

        return {
            'node_features': h,
            'graph_repr': graph_repr,
            'logits': logits,
            'contrastive_repr': contrastive_repr
        }


# 对比学习损失
class ContrastiveLoss(nn.Module):
    def __init__(self, temperature=0.1):
        super().__init__()
        self.temperature = temperature
        self.criterion = nn.CrossEntropyLoss()

    def forward(self, features, labels=None):
        batch_size = features.size(0)
        features = check_nan_inf(features, "Contrastive Features")
        features_norm = F.normalize(features, p=2, dim=1)
        features_norm = check_nan_inf(features_norm, "Normalized Contrastive Features")

        sim_matrix = torch.matmul(features_norm, features_norm.transpose(0, 1)) / self.temperature
        sim_matrix = check_nan_inf(sim_matrix, "Contrastive Similarity Matrix")

        if labels is not None:
            labels_expanded = labels.expand(batch_size, batch_size)
            mask = (labels_expanded == labels_expanded.t()).float()
        else:
            mask = torch.zeros(batch_size, batch_size, device=features.device)
            for i in range(0, batch_size, 2):
                mask[i, i + 1] = 1.0
                mask[i + 1, i] = 1.0

        mask.fill_diagonal_(0)
        exp_sim = torch.exp(sim_matrix)
        exp_sim = check_nan_inf(exp_sim, "Exponential Similarity Matrix")

        mask_sum = mask.sum(1, keepdim=True)
        mask_sum = torch.max(mask_sum, torch.ones_like(mask_sum))
        denom = (exp_sim * (1 - torch.eye(batch_size, device=features.device))).sum(1, keepdim=True)
        denom = torch.clamp(denom, min=1e-10)

        log_prob = sim_matrix - torch.log(denom)
        log_prob = check_nan_inf(log_prob, "Log Probability Matrix")

        loss = - (mask * log_prob).sum(1) / mask_sum
        loss = loss.mean()
        loss = check_nan_inf(loss.unsqueeze(0), "Contrastive Loss")[0]

        return loss


# 图数据增强
def graph_augmentation(edge_index, edge_attr, node_features, p_edge_drop=0.2, p_node_mask=0.1):
    augmented_edge_index = edge_index.clone()
    augmented_edge_attr = edge_attr.clone()
    augmented_node_features = node_features.clone()

    augmented_node_features = check_nan_inf(augmented_node_features, "Augmented Node Features")

    if p_edge_drop > 0 and edge_index.numel() > 0:
        num_edges = edge_index.size(1)
        mask = torch.rand(num_edges, device=edge_index.device) > p_edge_drop
        augmented_edge_index = augmented_edge_index[:, mask]
        augmented_edge_attr = augmented_edge_attr[mask]

    if p_node_mask > 0:
        num_nodes = node_features.size(0)
        mask = torch.rand(num_nodes, device=node_features.device) < p_node_mask
        augmented_node_features[mask] = 0.0

    return augmented_edge_index, augmented_edge_attr, augmented_node_features


# 训练函数 - 整合对比学习
def train(model, feature_extractor, graph_builder, dataloader, criterion_cls, criterion_contrastive,
          optimizer, device, epoch, config):
    model.train()
    feature_extractor.train()
    feature_extractor.clip_model.eval()  # 确保CLIP模型处于评估模式

    total_loss = 0.0
    total_cls_loss = 0.0
    total_contrastive_loss = 0.0
    correct = 0
    total = 0

    for batch_idx, data in enumerate(dataloader):
        images = data['image'].to(device)
        labels = data['sub_label'].to(device)

        # 特征提取
        features_dict = feature_extractor(images)
        node_features = features_dict['projected_features']
        cnn_features = features_dict['cnn_features']
        clip_features = features_dict['clip_features']

        # 构建图（不使用标签信息）
        edge_index, edge_attr = graph_builder.build_graph(
            node_features, cnn_features, clip_features
        )

        # 模型前向传播
        output_dict = model(node_features, edge_index, edge_attr)
        logits = output_dict['logits']
        contrastive_repr = output_dict['contrastive_repr']

        # 计算损失
        cls_loss = criterion_cls(logits, labels)
        contrastive_loss = criterion_contrastive(contrastive_repr, labels)
        loss = cls_loss + config['contrastive_weight'] * contrastive_loss

        # 梯度裁剪
        torch.nn.utils.clip_grad_norm_(feature_extractor.parameters(), max_norm=config['grad_clip'])
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=config['grad_clip'])

        # 反向传播和优化
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        total_cls_loss += cls_loss.item()
        total_contrastive_loss += contrastive_loss.item()

        _, predicted = logits.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

    avg_loss = total_loss / len(dataloader)
    avg_cls_loss = total_cls_loss / len(dataloader)
    avg_contrastive_loss = total_contrastive_loss / len(dataloader)
    accuracy = 100. * correct / total

    return avg_loss, avg_cls_loss, avg_contrastive_loss, accuracy


# 测试函数 - 收集详细预测结果
def test(model, feature_extractor, graph_builder, dataloader, criterion, device, collect_predictions=False):
    model.eval()
    feature_extractor.eval()
    feature_extractor.clip_model.eval()  # 确保CLIP模型处于评估模式

    test_loss = 0
    correct = 0
    total = 0

    # 用于收集详细预测结果
    all_labels = []
    all_predictions = []

    with torch.no_grad():
        for data in dataloader:
            images = data['image'].to(device)
            labels = data['sub_label'].to(device)

            features_dict = feature_extractor(images)
            node_features = features_dict['projected_features']
            cnn_features = features_dict['cnn_features']
            clip_features = features_dict['clip_features']

            # 构建图（不使用标签信息）
            edge_index, edge_attr = graph_builder.build_graph(
                node_features, cnn_features, clip_features
            )

            output_dict = model(node_features, edge_index, edge_attr)
            logits = output_dict['logits']

            loss = criterion(logits, labels)
            test_loss += loss.item()
            _, predicted = logits.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

            # 收集预测结果
            if collect_predictions:
                all_labels.extend(labels.cpu().numpy())
                all_predictions.extend(predicted.cpu().numpy())

    avg_loss = test_loss / len(dataloader)
    accuracy = 100. * correct / total

    return avg_loss, accuracy, (all_labels, all_predictions) if collect_predictions else None


# 混淆矩阵可视化函数
def plot_confusion_matrix(y_true, y_pred, class_names, title="混淆矩阵", figsize=(12, 10), normalize=False):
    """
    绘制混淆矩阵

    参数:
        y_true: 真实标签
        y_pred: 预测标签
        class_names: 类别名称列表
        title: 图表标题
        figsize: 图表大小
        normalize: 是否归一化
    """
    # 设置中文字体
    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]

    # 计算混淆矩阵
    cm = confusion_matrix(y_true, y_pred)

    # 归一化（可选）
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        fmt = '.2f'
        title = f"{title} (归一化)"
    else:
        fmt = 'd'
        title = f"{title} (原始数量)"

    # 创建图表
    plt.figure(figsize=figsize)
    sns.set(font_scale=1.2)
    sns.heatmap(cm, annot=True, fmt=fmt, cmap='Blues',
                xticklabels=class_names, yticklabels=class_names,
                cbar=True, square=True)

    plt.xlabel('预测类别', fontsize=14)
    plt.ylabel('真实类别', fontsize=14)
    plt.title(title, fontsize=16)
    plt.tight_layout()

    # 保存混淆矩阵图像
    filename = f"confusion_matrix_{'normalized' if normalize else 'raw'}.png"
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"混淆矩阵图像已保存为: {filename}")

    plt.show()

    # 返回混淆矩阵
    return cm


# 主函数
def main():
    config = {
        "epochs": 100,
        "batch_size": 32,
        "feature_dim": 512,
        "hidden_dim": 128,
        "output_dim": 256,
        "lr": 0.0001,
        "weight_decay": 5e-4,
        "contrastive_weight": 0.1,  # 对比学习损失权重
        "grad_clip": 1.0,  # 梯度裁剪阈值
        # 自适应KNN参数
        "knn_params": {
            "min_k": 1,
            "max_k": 10,
            "percentile": 30
        }
    }

    train_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
    ])

    test_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    train_data_path = r"D:/桌面/Trash-train"
    test_data_path = r"D:/桌面/Trash-test"

    # 创建数据集，启用语义隐藏
    train_dataset = GarbageDataset(root_dir=train_data_path, transform=train_transform, is_train=True)
    test_dataset = GarbageDataset(root_dir=test_data_path, transform=test_transform, is_train=False)

    # 数据泄露检查
    if check_data_leakage(train_dataset, test_dataset):
        print("由于存在数据泄露，训练终止。请检查数据集划分。")
        return

    print(f"训练集大小: {len(train_dataset)}")
    print(f"测试集大小: {len(test_dataset)}")
    print(f"总类别数: {len(train_dataset.classes)}")

    train_loader = DataLoader(train_dataset, batch_size=config["batch_size"], shuffle=True, num_workers=4)
    test_loader = DataLoader(test_dataset, batch_size=config["batch_size"], shuffle=False, num_workers=4)

    feature_extractor = FeatureExtractor(output_dim=config["feature_dim"]).to(device)
    graph_builder = DynamicGraphBuilder(device=device, knn_params=config["knn_params"])
    model = GNNModel(config["feature_dim"], config["hidden_dim"], config["output_dim"],
                     num_classes=len(train_dataset.classes)).to(device)

    criterion_cls = nn.CrossEntropyLoss()
    criterion_contrastive = ContrastiveLoss()

    # 优化器 - 为不同模块设置不同学习率
    optimizer = optim.Adam([
        {'params': feature_extractor.parameters(), 'lr': config["lr"]},
        {'params': model.parameters(), 'lr': config["lr"] * 2}  # 给GNN更高的学习率
    ], weight_decay=config["weight_decay"])

    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=5, verbose=True
    )

    best_acc = 0.0

    for epoch in range(config["epochs"]):
        # 训练阶段
        train_loss, cls_loss, contrastive_loss, train_accuracy = train(
            model, feature_extractor, graph_builder, train_loader,
            criterion_cls, criterion_contrastive, optimizer, device, epoch, config
        )

        # 测试阶段
        test_loss, test_accuracy, _ = test(
            model, feature_extractor, graph_builder, test_loader, criterion_cls, device
        )

        # 学习率调整
        scheduler.step(test_loss)

        # 保存最佳模型
        if test_accuracy > best_acc:
            best_acc = test_accuracy
            torch.save({
                'feature_extractor': feature_extractor.state_dict(),
                'model': model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'epoch': epoch,
                'acc': best_acc
            }, 'best_model.pth')

        # 输出详细结果
        print(f'Epoch {epoch + 1}/{config["epochs"]},'
              f'Train Loss: {train_loss:.4f} (Cls: {cls_loss:.4f}, Contrastive: {contrastive_loss:.4f}),'
              f'Train Acc: {train_accuracy:.2f}%, Test Loss: {test_loss:.4f}, Test Acc: {test_accuracy:.2f}%')

    print(f'训练完成！最佳测试准确率: {best_acc:.2f}%')

    # 加载最佳模型进行详细评估
    checkpoint = torch.load('best_model.pth')
    feature_extractor.load_state_dict(checkpoint['feature_extractor'])
    model.load_state_dict(checkpoint['model'])
    print(f"加载最佳模型 (Epoch {checkpoint['epoch']}, Acc: {checkpoint['acc']:.2f}%)")

    # 生成详细评估报告
    print("\n生成详细评估报告...")
    _, _, (true_labels, pred_labels) = test(
        model, feature_extractor, graph_builder, test_loader, criterion_cls, device, collect_predictions=True
    )

    # 获取类别名称
    class_names = train_dataset.classes

    # 生成评估报告
    report = classification_report(
        true_labels,
        pred_labels,
        target_names=class_names,
        digits=4
    )

    print("\n详细评估报告:")
    print(report)

    # 生成混淆矩阵
    print("\n生成混淆矩阵...")
    cm_raw = plot_confusion_matrix(true_labels, pred_labels, class_names, normalize=False)
    cm_normalized = plot_confusion_matrix(true_labels, pred_labels, class_names, normalize=True)

    # 计算并打印每个类别的精确率和错误率
    print("\n各类别的精确率和错误率:")
    for i, class_name in enumerate(class_names):
        # 精确率 = TP / (TP + FP)
        precision = cm_raw[i, i] / cm_raw[:, i].sum() if cm_raw[:, i].sum() > 0 else 0

        # 错误率 = 1 - 精确率
        error_rate = 1 - precision

        print(f"{class_name}: 精确率 = {precision:.4f}, 错误率 = {error_rate:.4f}")

    # 保存最终模型
    torch.save({
        'feature_extractor': feature_extractor.state_dict(),
        'model': model.state_dict(),
        'optimizer': optimizer.state_dict(),
        'epoch': epoch,
        'acc': test_accuracy
    }, 'final_model.pth')


if __name__ == "__main__":
    main()